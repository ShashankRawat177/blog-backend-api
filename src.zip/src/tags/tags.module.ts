import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

import { Tag } from './entities/tag.entity';
import { Post } from '../posts/entities/post.entity';

import { TagsController } from './tags.controller';
import { TagsService } from './tags.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      Tag,
      Post,
    ]),
  ],
  controllers: [TagsController],
  providers: [TagsService],
})
export class TagsModule {}